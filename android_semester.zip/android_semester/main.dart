import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const QuickActionsApp());
}

/// The root application configures the OLED-friendly Material 3 dark theme.
class QuickActionsApp extends StatelessWidget {
  const QuickActionsApp({super.key});

  @override
  Widget build(BuildContext context) {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: Colors.tealAccent,
      brightness: Brightness.dark,
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'QuickActions',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        colorScheme: colorScheme.copyWith(
          surface: const Color(0xFF101010),
          surfaceContainerHighest: const Color(0xFF1A1A1A),
          primary: Colors.tealAccent,
          onPrimary: Colors.black,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF111111),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFF292929)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Colors.tealAccent),
          ),
        ),
      ),
      home: const QuickActionsHomePage(),
    );
  }
}

/// The actions supported by the text detector.
enum ActionType {
  openLink,
  viewAddress,
  callNumber,
  whatsapp,
  trackPackage,
  searchGoogle,
  copyText,
  shareText,
}

class QuickAction {
  const QuickAction({
    required this.type,
    required this.label,
    required this.icon,
  });

  final ActionType type;
  final String label;
  final IconData icon;
}

class QuickActionsHomePage extends StatefulWidget {
  const QuickActionsHomePage({super.key});

  @override
  State<QuickActionsHomePage> createState() => _QuickActionsHomePageState();
}

class _QuickActionsHomePageState extends State<QuickActionsHomePage> {
  static const _historyKey = 'quick_actions_history';

  final _textController = TextEditingController();
  final _focusNode = FocusNode();
  final List<String> _history = <String>[];

  List<QuickAction> _actions = const <QuickAction>[];
  bool _isLoadingHistory = true;

  // These expressions deliberately cover common practical input formats while
  // avoiding overly broad matches that would make suggestions feel noisy.
  final _urlPattern = RegExp(
    r'(?:(?:https?|ftp)://|www\.)[^\s<>]+',
    caseSensitive: false,
  );
  final _phonePattern = RegExp(r'(?<!\w)(?:\+?\d[\d ()().-]{7,}\d)(?!\w)');
  final _trackingPattern = RegExp(r'(?<![A-Za-z0-9])[A-Za-z0-9]{12,22}(?![A-Za-z0-9])');
  final _addressPattern = RegExp(
    r'\b\d{1,6}\s+[A-Za-z0-9][A-Za-z0-9 .\'-]{2,},\s*[A-Za-z .\'-]{2,}',
    caseSensitive: false,
  );

  @override
  void initState() {
    super.initState();
    _textController.addListener(_updateSuggestions);
    _loadHistory();
  }

  @override
  void dispose() {
    _textController
      ..removeListener(_updateSuggestions)
      ..dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _updateSuggestions() {
    final text = _textController.text.trim();
    final actions = <QuickAction>[];

    if (text.isNotEmpty) {
      if (_urlPattern.hasMatch(text)) {
        actions.add(const QuickAction(
          type: ActionType.openLink,
          label: 'Open Link',
          icon: Icons.open_in_new,
        ));
      }
      if (_addressPattern.hasMatch(text)) {
        actions.add(const QuickAction(
          type: ActionType.viewAddress,
          label: 'View on Google Maps',
          icon: Icons.map_outlined,
        ));
      }
      if (_phonePattern.hasMatch(text)) {
        actions.addAll(const <QuickAction>[
          QuickAction(
            type: ActionType.callNumber,
            label: 'Call Number',
            icon: Icons.phone_outlined,
          ),
          QuickAction(
            type: ActionType.whatsapp,
            label: 'Send WhatsApp Message',
            icon: Icons.chat_outlined,
          ),
        ]);
      }
      if (_trackingPattern.hasMatch(text) && !_phonePattern.hasMatch(text)) {
        actions.add(const QuickAction(
          type: ActionType.trackPackage,
          label: 'Track Package',
          icon: Icons.local_shipping_outlined,
        ));
      }

      // Generic text actions are always useful, including alongside a
      // specialized suggestion for text that contains multiple data types.
      actions.addAll(const <QuickAction>[
        QuickAction(
          type: ActionType.searchGoogle,
          label: 'Search Google',
          icon: Icons.search,
        ),
        QuickAction(
          type: ActionType.copyText,
          label: 'Copy to Clipboard',
          icon: Icons.copy_outlined,
        ),
        QuickAction(
          type: ActionType.shareText,
          label: 'Share Text',
          icon: Icons.share_outlined,
        ),
      ]);
    }

    if (mounted) {
      setState(() => _actions = actions);
    }
  }

  Future<void> _loadHistory() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      final savedHistory = preferences.getStringList(_historyKey) ?? <String>[];
      if (!mounted) return;
      setState(() {
        _history
          ..clear()
          ..addAll(savedHistory.take(3));
        _isLoadingHistory = false;
      });
    } catch (_) {
      // The in-memory list remains a functional fallback if storage is not
      // available in the current web or embedded runtime.
      if (mounted) setState(() => _isLoadingHistory = false);
    }
  }

  Future<void> _rememberCurrentText() async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;

    _history
      ..remove(text)
      ..insert(0, text);
    if (_history.length > 3) _history.removeLast();
    if (mounted) setState(() {});

    try {
      final preferences = await SharedPreferences.getInstance();
      await preferences.setStringList(_historyKey, _history);
    } catch (_) {
      // Local state is still retained for this session when persistence fails.
    }
  }

  String _firstMatch(RegExp pattern) => pattern.firstMatch(_textController.text)?.group(0) ?? _textController.text.trim();

  String _digitsOnly(String value) => value.replaceAll(RegExp(r'[^0-9+]'), '');

  Future<void> _runAction(ActionType type) async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;
    await _rememberCurrentText();

    switch (type) {
      case ActionType.openLink:
        var url = _firstMatch(_urlPattern);
        if (url.toLowerCase().startsWith('www.')) url = 'https://$url';
        await _launch(Uri.parse(url));
      case ActionType.viewAddress:
        await _launch(Uri.https('www.google.com', '/maps/search/', {'api': '1', 'query': text}));
      case ActionType.callNumber:
        await _launch(Uri.parse('tel:${_digitsOnly(_firstMatch(_phonePattern))}'));
      case ActionType.whatsapp:
        await _launch(Uri.parse('https://wa.me/${_digitsOnly(_firstMatch(_phonePattern)).replaceFirst('+', '')}'));
      case ActionType.trackPackage:
        await _launch(Uri.https('www.google.com', '/search', {'q': '$text tracking'}));
      case ActionType.searchGoogle:
        await _launch(Uri.https('www.google.com', '/search', {'q': text}));
      case ActionType.copyText:
        await Clipboard.setData(ClipboardData(text: text));
        _showMessage('Copied to clipboard');
      case ActionType.shareText:
        // A mailto share fallback works on web and mobile without requiring a
        // platform-specific share API or an additional package.
        await _launch(Uri(
          scheme: 'mailto',
          queryParameters: <String, String>{
            'subject': 'Shared from QuickActions',
            'body': text,
          },
        ));
    }
  }

  Future<void> _launch(Uri uri) async {
    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched && mounted) _showMessage('Could not open this action');
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _clearText() {
    _textController.clear();
    _focusNode.requestFocus();
  }

  void _restoreHistory(String value) {
    _textController
      ..text = value
      ..selection = TextSelection.collapsed(offset: value.length);
    _focusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('QuickActions', style: TextStyle(fontWeight: FontWeight.w700)),
        centerTitle: false,
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final contentWidth = constraints.maxWidth > 720 ? 680.0 : double.infinity;
            return Center(
              child: SizedBox(
                width: contentWidth,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
                  children: [
                    TextField(
                      controller: _textController,
                      focusNode: _focusNode,
                      minLines: 4,
                      maxLines: 8,
                      textInputAction: TextInputAction.newline,
                      decoration: InputDecoration(
                        hintText: 'Paste text, a link, address, phone number...',
                        alignLabelWithHint: true,
                        contentPadding: const EdgeInsets.fromLTRB(18, 18, 8, 12),
                        suffixIcon: _textController.text.isEmpty
                            ? null
                            : TextButton(onPressed: _clearText, child: const Text('Clear')),
                      ),
                    ),
                    const SizedBox(height: 28),
                    if (_actions.isNotEmpty) ...[
                      const Text(
                        'Suggested Actions',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 12),
                      ..._actions.map(_buildActionTile),
                    ] else ...[
                      const _EmptyState(),
                    ],
                    const SizedBox(height: 28),
                    _buildHistory(),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildActionTile(QuickAction action) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        color: const Color(0xFF111111),
        margin: EdgeInsets.zero,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFF292929)),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => _runAction(action.type),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
            child: Row(
              children: [
                Icon(action.icon, color: Colors.tealAccent),
                const SizedBox(width: 14),
                Expanded(child: Text(action.label, style: const TextStyle(fontWeight: FontWeight.w600))),
                const Icon(Icons.arrow_forward_ios, size: 15, color: Colors.white54),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHistory() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Recent', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        if (_isLoadingHistory)
          const LinearProgressIndicator(minHeight: 2)
        else if (_history.isEmpty)
          const Text('Processed text will appear here.', style: TextStyle(color: Colors.white54))
        else
          ..._history.map(
            (item) => ListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              leading: const Icon(Icons.history, color: Colors.white54),
              title: Text(item, maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: () => _restoreHistory(item),
            ),
          ),
      ],
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 18),
      child: Column(
        children: [
          Icon(Icons.auto_awesome_outlined, size: 34, color: Colors.white38),
          SizedBox(height: 10),
          Text('Paste something to see useful actions.', style: TextStyle(color: Colors.white54)),
        ],
      ),
    );
  }
}
